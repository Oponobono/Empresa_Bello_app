package com.example.empresabello;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.JsonRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class UsuariosActivity extends AppCompatActivity implements Response.Listener<JSONObject>,Response.ErrorListener {

    EditText jetusuario, jetnombre, jetcorreo, jetclave;
    CheckBox jcbactivo;
    String usr,nombre,correo,clave,url;
    RequestQueue rq;
    JsonRequest jrq;
    Button reactivar;
    byte sw,cap;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usuarios);

        /*Ocultar Barra de Menú por defecto, asociar objetos java con objetos XML e inicializar la
        cola de respuestas json*/

        getSupportActionBar().hide();

        jetusuario = findViewById(R.id.etusuario);
        jetnombre = findViewById(R.id.etnombre);
        jetcorreo = findViewById(R.id.etcorreo);
        jetclave = findViewById(R.id.etclave);
        jcbactivo = findViewById(R.id.cbactivo);

        rq = Volley.newRequestQueue(this);


        reactivar = findViewById(R.id.btnAnularUsr);
        reactivar.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                usr = jetusuario.getText().toString();
                if(usr.isEmpty()) {
                    cap = 1;
                    Toast.makeText(UsuariosActivity.this, "Ingresa un usuario", Toast.LENGTH_SHORT).show();

                }else {
                    cap = 2;
                    url = "Http://192.168.1.18:80/WebServices/reactivausr.php";
                }

                StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                        new Response.Listener<String>()
                        {
                            @Override
                            public void onResponse(String response) {
                                if(cap == 2){
                                    Limpiar_campos();
                                    Toast.makeText(getApplicationContext(), "Registro reactivado!", Toast.LENGTH_LONG).show();
                                }
                            }
                        },
                        new Response.ErrorListener()
                        {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                if(cap == 2){
                                    Toast.makeText(getApplicationContext(), "Error reactivando registro!", Toast.LENGTH_LONG).show();
                                }
                            }
                        }
                ) {
                    @Override
                    protected Map<String, String> getParams()
                    {
                        Map<String, String> params = new HashMap<>();
                        params.put("usr",jetusuario.getText().toString().trim());
                        params.put("estado", "si");
                        return params;
                    }
                };

                RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                requestQueue.add(postRequest);

                return true;
            }
        });

    }
    
    public void Consultar(View view){
        usr = jetusuario.getText().toString();
        if (usr.isEmpty()){
            Toast.makeText(this, "Usuario requerido para la consulta", Toast.LENGTH_SHORT).show();
            jetusuario.requestFocus();
        }else{
            url = "Http://192.168.1.18:80/WebServices/consulta.php?usr="+usr;
            jrq = new JsonObjectRequest(Request.Method.GET, url,null,this,this);
            rq.add(jrq);
        }
    }
    
    public void Limpiar(View view){
        Limpiar_campos();
    }

    public void Regresar(View view){
        Intent intmain =new Intent(this,MainActivity.class);
        startActivity(intmain);
    }

    @Override
    public void onErrorResponse(VolleyError error) {
        Toast.makeText(this, "Usuario no registrado", Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onResponse(JSONObject response) {
        sw=1;
        Toast.makeText(this, "Usuario registrado", Toast.LENGTH_SHORT).show();
        JSONArray jsonArray = response.optJSONArray("datos");
        JSONObject jsonObject;
        try {
            jsonObject = jsonArray.getJSONObject(0);//posicion 0 del arreglo....
            jetnombre.setText(jsonObject.optString("nombre"));
            jetcorreo.setText(jsonObject.optString("correo"));
            jetclave.setText(jsonObject.optString("clave"));
            jcbactivo.setChecked(jsonObject.optString("estado").equals("si"));
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }
    }

    public void Guardar(View view){
        usr = jetusuario.getText().toString();
        nombre = jetnombre.getText().toString();
        correo = jetcorreo.getText().toString();
        clave = jetclave.getText().toString();
        if (usr.isEmpty() || nombre.isEmpty() || correo.isEmpty() || clave.isEmpty()){
            Toast.makeText(this, "Es necesario ingresar todos los datos para realizar el registro", Toast.LENGTH_SHORT).show();
            if(usr.isEmpty()){jetusuario.requestFocus();}
            else if(nombre.isEmpty()){jetnombre.requestFocus();}
            else if(correo.isEmpty()){jetcorreo.requestFocus();}
            else{jetclave.requestFocus();}
        }else{
            if(sw == 0) {
                url = "Http://192.168.1.18:80/WebServices/registrocorreo.php";
            }else {
                url = "Http://192.168.1.18:80/WebServices/actualiza.php";
                sw = 0;
            }

            StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>()
                    {
                        @Override
                        public void onResponse(String response) {
                            Limpiar_campos();
                            Toast.makeText(getApplicationContext(), "Registro guardado!", Toast.LENGTH_LONG).show();
                        }
                    },
                    new Response.ErrorListener()
                    {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(getApplicationContext(), "Error guardando registro!", Toast.LENGTH_LONG).show();
                        }
                    }
            ) {
                @Override
                protected Map<String, String> getParams()
                {
                    Map<String, String> params = new HashMap<>();
                    params.put("usr",jetusuario.getText().toString().trim());
                    params.put("nombre", jetnombre.getText().toString().trim());
                    params.put("correo",jetcorreo.getText().toString().trim());
                    params.put("clave",jetclave.getText().toString().trim());
                    return params;
                }
            };

            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(postRequest);
        }
    }

    public void Eliminar(View view) {
        if (sw == 0) {
            Toast.makeText(this, "Para eliminar primero debe realizar una consulta", Toast.LENGTH_SHORT).show();
            jetusuario.requestFocus();
        } else {
            url = "Http://192.168.1.18:80/WebServices/elimina.php";
            sw = 0;


                StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                Limpiar_campos();
                                Toast.makeText(getApplicationContext(), "Registro eliminado!", Toast.LENGTH_LONG).show();
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Toast.makeText(getApplicationContext(), "Error eliminando registro!", Toast.LENGTH_LONG).show();
                            }
                        }
                ) {
                    @Override
                    protected Map<String, String> getParams() {
                        Map<String, String> params = new HashMap<>();
                        params.put("usr", jetusuario.getText().toString().trim());
                        return params;
                    }
                };
                RequestQueue requestQueue = Volley.newRequestQueue(this);
                requestQueue.add(postRequest);
            }
    }

    public void Anular(View view) {
        if (sw == 0) {
            Toast.makeText(this, "Para anular primero debe realizar una consulta", Toast.LENGTH_SHORT).show();
            jetusuario.requestFocus();
        } else {
            url = "Http://192.168.1.18:80/WebServices/anula.php";
            sw = 0;


            StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            Limpiar_campos();
                            Toast.makeText(getApplicationContext(), "Registro anulado!", Toast.LENGTH_LONG).show();
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(getApplicationContext(), "Error anulando registro!", Toast.LENGTH_LONG).show();
                        }
                    }
            ) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();
                    params.put("usr", jetusuario.getText().toString().trim());
                    return params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(postRequest);
        }
    }






    private void Limpiar_campos(){
        jetusuario.setText("");
        jetnombre.setText("");
        jetcorreo.setText("");
        jetclave.setText("");
        jcbactivo.setChecked(false);
        jetusuario.requestFocus();
        sw=0;
    }

}
