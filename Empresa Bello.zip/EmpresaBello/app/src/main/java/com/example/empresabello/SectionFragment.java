package com.example.empresabello;

import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.text.Editable;
import android.util.JsonReader;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.JsonRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.net.ResponseCache;

public class SectionFragment extends Fragment implements Response.Listener<JSONObject>,Response.ErrorListener {

    EditText jetCorreo,jetClave;
    Button jbtIngresar;
    TextView jtvRegistrar;
    RequestQueue rq;
    JsonRequest jrq;
    String url,usr,nombre,correo,clave,nameResult;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_section, container, false);
        View vista = inflater.inflate(R.layout.fragment_section,container,false);
        jetCorreo = vista.findViewById(R.id.etCorreo);
        jetClave = vista.findViewById(R.id.etClave);
        jbtIngresar = vista.findViewById(R.id.btIngresar);
        jtvRegistrar = vista.findViewById(R.id.tvRegistrar);
        jbtIngresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Iniciar_sesion();
            }
        });
        jtvRegistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    Registrarse();
            }
        });
        rq = Volley.newRequestQueue(getContext());//conexion a internet
        return vista;
    }

    private void Iniciar_sesion(){
        correo = jetCorreo.getText().toString();
        clave = jetClave.getText().toString();
        if(correo.isEmpty() || clave.isEmpty()){
            Toast.makeText(getContext(), "Correo y clave son requeridos", Toast.LENGTH_SHORT).show();
            jetCorreo.requestFocus();
        }else {
            url = "Http://192.168.1.18:80/WebServices/ingreso.php?correo="+correo+"&clave="+clave+"";
            jrq = new JsonObjectRequest(Request.Method.GET, url,null,this,this);
            rq.add(jrq);
        }
    }

    @Override
    public void onErrorResponse(VolleyError error) {
        Toast.makeText(getContext(), "Error consultando correo y clave", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onResponse(JSONObject response) {
        Toast.makeText(getContext(), "Consulta exitosa", Toast.LENGTH_SHORT).show();
        JSONArray jsonArray = response.optJSONArray("datos");
        JSONObject jsonObject;
        try {
            jsonObject = jsonArray.getJSONObject(0);//posicion 0 del arreglo....
            nameResult = jsonObject.optString("nombre");
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }
        Intent intventas = new Intent(getContext(),VentasActivity.class);
        intventas.putExtra("userName", nameResult);
        startActivity(intventas);
    }

    private void Registrarse(){
        Intent intusuarios = new Intent(getContext(),UsuariosActivity.class);
        startActivity(intusuarios);
    }
}